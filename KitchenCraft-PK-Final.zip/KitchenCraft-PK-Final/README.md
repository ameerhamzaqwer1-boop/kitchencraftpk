# KitchenCraft PK - GitHub Pages Website

## Files
- `index.html` - website structure
- `style.css` - luxury design and responsive layout
- `script.js` - WhatsApp ordering + mobile menu
- `images/` - your 5 product photos

## Before publishing
Open `script.js` and change:

const WHATSAPP_NUMBER = "923001234567";

to your real Pakistan WhatsApp number.

Example:
const WHATSAPP_NUMBER = "923xxxxxxxxx";

Do NOT add `+`, spaces, brackets, or the first `0`.

## Publish with GitHub Pages
1. Create a GitHub account at https://github.com/
2. Create a new repository named `KitchenCraft-PK`
3. Upload `index.html`, `style.css`, `script.js`, and the `images` folder.
4. Open the repository's **Settings**.
5. Open **Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select the `main` branch and `/ (root)`.
8. Save.
9. GitHub will provide your live website address.

## Changing a product
In `index.html`, find the product card and change:
- product name
- description
- image filename
- WhatsApp product name

The current site intentionally says "Price on WhatsApp" because no product prices were supplied yet.


Final product prices: Kettle Rs. 2,500; Water Set Rs. 2,000; Sandwich Maker Rs. 3,500; Infrared Cooker Rs. 4,000; 3-Piece Casserole Set Rs. 1,700. WhatsApp: 03019088013.
