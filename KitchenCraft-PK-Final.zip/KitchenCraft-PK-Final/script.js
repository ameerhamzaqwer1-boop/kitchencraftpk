// ===============================
// KitchenCraft PK - Website Setup
// ===============================
// IMPORTANT: Replace this with YOUR WhatsApp number.
// Pakistan format: 92 + mobile number, without +, spaces or leading 0.
// Example: 923019088013

const WHATSAPP_NUMBER = "923019088013";

function whatsappLink(product) {
  const message = product === "General Inquiry"
    ? "Hello KitchenCraft PK, I want to know more about your products."
    : `Hello KitchenCraft PK, I want to order the ${product}. Please share the price and details.`;

  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

document.querySelectorAll("[data-whatsapp]").forEach((link) => {
  link.href = whatsappLink(link.dataset.whatsapp);
});

const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

if (menuToggle) {
  menuToggle.addEventListener("click", () => {
    navLinks.classList.toggle("open");
  });
}

document.querySelectorAll(".nav-links a").forEach((link) => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});
